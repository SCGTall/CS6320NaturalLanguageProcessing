Name: Chaoran Li
Email: cxl190012@utdallas.edu
Homework Number: NLP CS6320.002
Solve: Project Phase A

I am in charge of X1 for my team. My annotations are wrote in X1_train_labels.json in the format of example_train_labels.json which is given.

GLHF
