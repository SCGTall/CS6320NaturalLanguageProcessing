Name: Chaoran Li
Email: cxl190012@utdallas.edu
Homework Number: NLP CS6320.002
Solve: Homework 2 for all Problem 1-3 (Coding for Problem 2 and 3)

Problem 2
A)
Code: hw2_CKYparser.py
Description:
Automatically parsed with my Cocke-Kasami-Younger (CKY) parser.
How to operate:
python3 hw2_CKYparser.py grammars.txt sentences.txt p1_output.txt

Problem 3
Code: Problem3.py
Description:
Automatically generated dependency trees for given sentences.
Could not terminate because of opening a webpage. Need meanually shutdown.
How to operate:
python3 Problem3.py

All results have been explained in Solution.pdf
